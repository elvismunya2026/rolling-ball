ROLLING BALL 3D — ELVISMUNYA2026

PUBLICAR NO NETLIFY (para obter um endereço que abre no Chrome/Firefox)
1. Descarregue e extraia o ZIP.
2. Entre na sua conta em https://app.netlify.com/drop
3. Arraste a pasta rolling_ball_3d (a pasta que contém index.html) para a zona de publicação.
4. Aguarde a publicação. O Netlify mostrará um endereço terminado em .netlify.app.
5. Abra esse endereço no Chrome e Firefox e partilhe com os amigos.
6. No painel do Netlify, pode mudar o nome do site em Site configuration > Change site name, se o nome estiver disponível.

O jogo carrega Three.js pela Internet através de CDN; precisa de ligação à Internet.
Controlos: WASD/setas; Espaço para saltar. No telemóvel aparecem botões táteis.
Tem 200 níveis gerados automaticamente, moedas, obstáculos, checkpoints de progressão,
recorde local e contador de partidas neste navegador.

NOTA SOBRE ESTATÍSTICAS:
O número mostrado é de partidas iniciadas neste aparelho/navegador. Não é ainda um contador
global de jogadores únicos. Para estatísticas globais é necessária uma base de dados online
(ex.: Supabase) e configuração adicional. Não anunciar o número local como total de jogadores.
