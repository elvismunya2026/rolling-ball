ROLLING BALL — Produced by ELVISMUNYA2026

This is an original browser game inspired by the broad gameplay idea of 3D rolling-ball sea races.
It is not the CrazyGames game and does not use its source code, name, artwork, or assets.

HOW TO PLAY
- Player 1: W A S D (or arrow keys in 1-player mode)
- Player 2: Arrow keys
- Space: jump (Player 1)
- R: restart
- Collect gold rings, avoid blocks, and reach the finish.

PUBLISH ON NETLIFY
1. Extract this ZIP file.
2. Open https://app.netlify.com/drop
3. Drag the extracted folder (the folder containing index.html) onto the page.
4. Wait for Netlify to publish and show your .netlify.app address.

The game loads Three.js from jsDelivr, so an internet connection is required.
